DATA CLEANING & VISUALIZATION MINI PROJECT

1. Place your dataset as sales_data.csv
2. Run project.py
3. Cleaned data is saved as cleaned_data.csv
4. Visualization is displayed using Matplotlib
