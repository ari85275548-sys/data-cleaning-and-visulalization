import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('sales_data.csv')

print(df.head())
print(df.isnull().sum())

df = df.fillna(0)
df = df.drop_duplicates()

df.to_csv('cleaned_data.csv', index=False)

df.hist(figsize=(8,6))
plt.suptitle('Data Visualization')
plt.show()

print('Project Completed Successfully')
